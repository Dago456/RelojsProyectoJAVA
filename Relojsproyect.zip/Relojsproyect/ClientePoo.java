public class ClientePoo
{
    String Id;
    String nombre;
    double relojuno;
    double relojdos;
    }